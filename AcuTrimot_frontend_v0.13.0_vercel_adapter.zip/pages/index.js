export default function Home(){ return (<main style={{fontFamily:'system-ui',margin:24}}>
<h1>AcuTrimot Frontend</h1>
<ul>
  <li><a href="/payments/demo">Payments Demo</a></li>
</ul>
</main>); }